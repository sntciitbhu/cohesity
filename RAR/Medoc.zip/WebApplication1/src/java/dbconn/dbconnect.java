/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dbconn;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author Dell
 */
public class dbconnect {
    static Connection co;
	public static Connection getconnection() throws SQLException
	{
 		
 			
		try
		{
			Class.forName("com.mysql.jdbc.Driver");	
			co = DriverManager.getConnection("jdbc:mysql://localhost:3306/doctor","root","mysql");
		}
		catch(ClassNotFoundException e)
		{
			System.out.println("Database Error"+e);
		}
		return co;
	}
    
    
    
    
}
